"""优先技术web 的使用"""
import webbrowser
import os
import time
import platform
from _datetime import datetime
from get_env_info import ret_dict_obj, ck_env_technique, ck_env_leader
from lib.selenium import webdriver
from lib.selenium.webdriver import ChromeOptions, FirefoxOptions
from lib.selenium.webdriver.common.action_chains import ActionChains
from lib.selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from subprocess import Popen, PIPE
from oper_env import win_platform, oper_environment, start_browser
from sen_log import ServiceLog

log_oper = ServiceLog(log_name='ff_{}_{}_{}.log'.format(datetime.now().year, datetime.now().month,
                                                     datetime.now().day))
log_write = log_oper.logger_writer('{}'.format(datetime.now().day))
listen_port = 9762
environment = ret_dict_obj().env
print(environment)
# ff_mac_install_path = "/Applications/Firefox.app/Contents/MacOS/firefox"
# ff_mac_bin_path = FirefoxBinary("/Applications/Firefox.app/Contents/MacOS/firefox-bin")
# print('ff_mac_bin_path:{}'.format(ff_mac_bin_path))
""""""


# driver operate
class driver_operate(object):
    _blank_xpath = '/html/body/div[3]/div[2]/div[2]/div[1]/table/tbody/tr[2]/td[1]/a'
    # /html/body/div[3]/div[2]/div[2]/div[1]/table/tbody/tr[2]/td[1]/a
    _start_xpath = '/html/body/div[3]/div[2]/button[1]'
    _course_lis = []

    def __init__(self, port=None):
        if not port:
            self.port = listen_port
        else:
            self.port = port

    def create_ff_driver(self):
        """create browser object"""
        profile = webdriver.FirefoxProfile()
        # profile.set_preference("network.proxy.type", 1)
        profile.set_preference("network.proxy.http", "127.0.0.1")
        profile.set_preference("network.proxy.http_port", self.port)
        # profile.set_preference("network.proxy.no_proxies_on", "")
        profile.port = self.port
        profile.update_preferences()
        # driver = webdriver.Firefox(firefox_profile=profile)
        profile_name = os.path.join(profile.path, os.listdir(profile.path)[0])
        print('profile:{} , profile.path:{} list:{}'.format(profile, profile.path, profile_name))

        ff_option = FirefoxOptions()
        # catp = DesiredCapabilities().FIREFOX # 避免版本不匹配问题，
        # catp['marionette'] = False     # 避免版本不匹配
        ff_option.profile = profile.path
        # chrom_option.add_experimental_option('debuggerAddress', '127.0.0.1:9222')
        # diver 是当前窗口 firefox_binary=ff_mac_bin_path,
        driver = webdriver.Firefox(executable_path=oper_environment.ff_driver_path(), firefox_options=ff_option)
        # driver = webdriver.Chrome(executable_path=oper_environment.brow_driver_path(), chrome_options=ff_option)
        log_write.info('Info create driver {}'.format(driver, driver.current_url))
        return driver

    def create_driver(self):
        """create browser object"""
        chrom_option = ChromeOptions()
        chrom_option.debugger_address = '127.0.0.1:{}'.format(self.port)
        # chrom_option.add_experimental_option('debuggerAddress', '127.0.0.1:9222')
        # diver 是当前窗口
        driver = webdriver.Chrome(executable_path=oper_environment.brow_driver_path(), chrome_options=chrom_option)
        log_write.info('Info create driver {}'.format(driver, driver.current_url))
        return driver

    @staticmethod
    def get_wind_now(driver):
        # get windows now
        try:
            nowhandle = driver.current_window_handle
            return nowhandle
        except (BaseException, Exception) as err:
            log_write.debug('Info error:{} driver:{}'.format(err, driver))
        # print('now windows', nowhandle)

    @staticmethod
    def get_wind_all(driver):
        allhandle = driver.window_handles
        # print('all windows', allhandle)
        log_write.info('Info all handle all type:{} windows:{}'.format(type(allhandle), allhandle))
        return allhandle

    def find_blank_start(self, driver):
        """ start detail lesson web """
        try:
            a_list = driver.find_element_by_xpath(
                self._blank_xpath)  # because the page renewed the table when driver refreshed
        except (BaseException, Exception) as err:
            log_write.debug('Warning all handle all type:{} windows:{}'.format(err, driver))
            a_list = []
        if not a_list:
            return False
        else:
            return a_list

    def start_blank(self, driver):
        """start detail product in new web page"""
        # driver.maximize_window()    # maximize page
        driver.implicitly_wait(1)  # wait
        try:
            driver.refresh()  # refresh page
            driver.implicitly_wait(5)  # wait for load
        except (BaseException, Exception) as es:
            log_write.debug('Error, refresh fail:{},driver:{}'.format(es, driver))
        try:
            a_list = driver.find_element_by_xpath(
                self._blank_xpath)  # because the page renewed the table when driver refreshed
            # print(a_list)
            log_write.info('Info url:{}, click product {}'.format(driver.current_url, a_list))
            # print(type(a_list))
            # print('a_list', a_list)
            actions = ActionChains(driver)  # create action
            actions.move_to_element(a_list).click(a_list)  # move to acton and click
            actions.perform()  # exec action
            time.sleep(3)  # wait for success
        except (BaseException, Exception) as ebk:
            # print('find tag name fail', ebk, driver)
            log_write.debug('Warning not find tag name info msg: {}, driver:{}'.format(ebk, driver))
            log_write.debug('Please check The page is right driver ??:{}t, and login, '.format(driver))
            a_list = []
        return a_list

    def try_find_start_page(self, driver):
        """find xpath button"""
        # /html/body/div[3]/div[2]/button[1]
        try:
            start_prog = driver.find_element_by_xpath(self._start_xpath)  # click button to start progress
            log_write.info('Info, xpath: {}  url:{}'.format(self._start_xpath, driver.current_url))
        except (BaseException, Exception) as es:
            log_write.debug('Error, xpath: {} find path error {}, driver:{}'.format(self._start_xpath, es, driver))
            return False
        else:
            return start_prog

    def try_click_start(self, driver, start_prog):
        """just try to click start button"""
        try:
            actions = ActionChains(driver)
            actions.move_to_element(start_prog).click(start_prog)

            actions.perform()  # do the action
            log_write.info('success try start action {} error msg: {}, driver:{}'.format(start_prog, 'succ', driver))
        except (BaseException, Exception) as bt:
            log_write.debug('Error try start action {} error msg: {}, driver:{}'.format(start_prog, bt, driver))

    def start_page(self, driver):
        """find and click to start study """
        try:
            time.sleep(5)  # wait for load
            # alert = Alert(driver).accept()
            self.try_to_acc_alert(driver)
            # alert1 = driver.switch_to.alert.accept()
            # print('find alert and accept')
            log_write.info('Find alert accept msg url:{}'.format(driver.current_url))
        except (BaseException, Exception) as ec:
            log_write.debug('Warning not find alert info msg: {}, url:{}'.format(ec, driver))
        all_handle = self.get_wind_all(driver)
        try:
            start_prog = driver.find_element_by_xpath(self._start_xpath)  # click button to start progress
            # menu = driver.find_element_by_css_selector(".nav")
            self._course_lis.append(driver.current_url)
            log_write.info('Info this page find succ url:{}, click product: {}'.format(driver.current_url, start_prog))
            log_write.info('Info this loop No.{}, course list:{}'.format(len(self._course_lis), self._course_lis[-1:]))
            self.try_click_start(driver, start_prog)
            time.sleep(3)  # wait for new windows
            self.try_to_acc_alert(driver)
            time.sleep(2)  # wait for new windows
            all_handle_new = self.get_wind_all(driver)
            if len(all_handle_new) > len(all_handle):   # 启动vedio成功
                try:
                    driver.close()  # close current start web
                except (BaseException, Exception) as dc:
                    log_write.debug('driver close fail msg: {}, driver:{}'.format(dc, driver))
            else:
                return False
        except (BaseException, Exception) as be:
            log_write.info('button not found :{}, driver:{}'.format(be, driver))
            log_write.debug('Error page no button.btn msg: {}, url:{}'.format(be, driver))
            start_prog = []
        # pass
        return start_prog

    # @staticmethod
    def try_to_acc_alert(self, driver):
        """wait for alert in page by loop alert"""
        t = 0
        while t < 3:
            if t >= 3:
                break
            print('to find alert msg try: {} time'.format(t))
            t += 1
            time.sleep(2)
            try:
                driver.switch_to.alert.accept()  # 同意
                log_write.info('Info url:{}, alert accept succ driver: {}, wait times{}'.format(driver.current_url, driver, t))
            except (BaseException, Exception) as e1:
                log_write.debug('Error Warning try to accept alert fail msg: {}, url:{}'.format(e1, driver))
                continue
            else:
                time.sleep(3)  # wait for web page load
                log_write.info(
                    'Info url:{}, alert accept succ driver: {}, wait times{}'.format(driver.current_url, driver, t))
                driver.close()
                return None

    def start_product_page(self, driver, nowhandle):
        """ 尝试启动vedio页面
        调用这个函数时，应该有两个windows，去掉nowhandle，去另一个windows尝试启动vedio界面
        :param driver the program handler
        :param nowhandle the program start main page
        """
        allhandle = self.get_wind_all(driver)
        log_write.info('Info driver {}  allhandle is:{}, nowhandle:{}'.format(driver, allhandle, nowhandle))
        if not allhandle:
            return False
        if not nowhandle:
            log_write.info('Error driver {} nowhandle is:{}'.format(driver, nowhandle))
            return False
        if nowhandle not in allhandle:
            log_write.info('Error driver {}  allhandle is:{}'.format(driver, allhandle))
            return False
        log_write.info('Info driver {} from allhandle remove nowhandle:{}'.format(driver, allhandle))
        switch_windows(driver, allhandle[-1])
        try:
            start_button = self.try_find_start_page(driver)
            if start_button:
                self.start_page(driver)
        except (BaseException, Exception) as bw:
            log_write.debug('Error Start_page click button fail:{}'.format(driver, bw))
        else:
            log_write.info('Info Start_page click button Success on windows:{}'.format(driver, allhandle[-1]))
            return True

    def exec_progress(self, driver, nowhandle):
        """executor 26s each round
        :param driver the program handler
        :param nowhandle the program start main page"""
        x = 0
        # most longer conform is 4 hours = 4 * 60 * 60 seconds
        while x < 100:
            """product wait page, most 15s each loop"""
            x += 1
            start_product = self.start_product_page(driver, nowhandle)
            if not start_product:
                log_write.info('Continue Start_page on :{} click button fail:{}'.format(driver, start_product))
                continue
            allhandle = self.get_wind_all(driver)
            log_write.info('Info all window num:{}, try:{}'.format(len(allhandle), x))
            if len(allhandle) == 1:
                break
            for handle in allhandle:
                print('switch to window', handle)
                log_write.info('Info now handle: {} switch success Now next window :{}'.format(nowhandle, handle))
                time.sleep(1)
                if handle != nowhandle:
                    try:
                        switch_windows(driver, handle)
                        self.try_to_acc_alert(driver)
                        log_write.info('Info switch url: {} success Now next window try_to_acc_alert:{}'.format(driver.current_url, handle))
                    except (BaseException, Exception) as sw_error:
                        log_write.debug('Error Warning switch window failure: {} error:{} try continue'.format(handle, sw_error))

                    try:
                        self.try_to_acc_alert(driver)
                    except (BaseException, Exception) as hane:
                        log_write.debug('Error Warning next window: {} try alert fail:{}'.format(handle, hane))
                        switch_windows(driver, allhandle[-1])
                        break
                else:
                    switch_windows(driver, allhandle[-1])
                    log_write.debug('Warning switch next blank window: {} nowhandle:{}'.format(handle, nowhandle))
                    continue


import random


def renew_listen_port():
    """find a port to listen"""
    while True:
        rand_port = random.choice(range(1000, 10000))
        if win_platform():
            cmd_port = 'netstat -an | findstr {}'.format(rand_port)
        else:
            cmd_port = 'netstat -an | grep {}'.format(rand_port)
        pp = Popen(cmd_port, stdout=PIPE, stdin=PIPE, stderr=PIPE, shell=True)
        info, err = pp.communicate()
        if not info or info in ['', "b''", []]:
            pp.kill()
            return int(rand_port)
        else:
            pp.kill()
            continue


def switch_windows(driver, wind):
    log_write.info('Switch windows frome {} to :{}'.format(driver, wind))
    try:
        driver.switch_to.window(wind)  # switch windows to product table page

    except (BaseException, Exception) as swerr:
        log_write.info('Error switch windows error:{}, now:{}'.format(swerr, driver.current_window_handle))
        return False
    else:
        log_write.info('Success switch windows dest :{}, now:{}'.format(wind, driver.current_window_handle))
        return True


# start operate product page
# create driver
def product_page_start(port):
    """listen specifically port and operate 启动浏览器，开始监听"""
    doper = driver_operate(port)
    driver = doper.create_driver()
    # start a product， default 300, 300 * 0.5 = 150 score
    for pn in range(300):
        log_write.info('switch windows wait 5s for times:{}'.format(pn))
        time.sleep(3)
        allhandle = doper.get_wind_all(driver)  # get all handle windows
        log_write.info('allhandle windows for:{}'.format(allhandle))
        try:
            nowhandle = doper.get_wind_now(driver)
            switch_windows(driver, nowhandle)
            log_write.info('tech env success switch now windows:{}'.format(nowhandle))
        except (BaseException, Exception) as sw_error:
            log_write.debug('Error Warning switch window failure doper: {} error:{} try continue'.format(doper, sw_error))
            continue

        log_write.info('try to find blank on now windows:{}'.format(nowhandle))

        if not doper.find_blank_start(driver):
            log_write.debug('Warning find blank to start failure: now handler {} diver:{} try continue'.format(nowhandle, driver))
            continue
        else:
            doper.start_blank(driver)  # 9s open new windows to start progress page
        allhandle = doper.get_wind_all(driver)  # get all handle windows
        log_write.info('Info now all handle on windows:{}'.format(allhandle))
        if len(allhandle) == 1:
            if not nowhandle:
                continue
            doper.start_blank(driver)  # 9s open new windows to start progress page
            log_write.info('success start_blank windows on driver:{}'.format(nowhandle))
        doper.exec_progress(driver, nowhandle)  # check pop windows


from concurrent.futures import ProcessPoolExecutor
import asyncio


page = "https://pro.learning.gov.cn/"
async def tasks(op_port):
    tasks = [
        loop.run_in_executor(executor, start_browser, *(op_port, page)),
        loop.run_in_executor(executor, product_page_start, op_port)
    ]
    await asyncio.gather(*tasks)


if __name__ == '__main__':
    pass
    op_port = renew_listen_port()
    #
    loop = asyncio.get_event_loop()
    executor = ProcessPoolExecutor(max_workers=2)
    # try:
    loop.run_until_complete(tasks(op_port))
    # product_page_start(port=6000)

