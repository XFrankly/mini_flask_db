import sys
import random
import multiprocessing
import asyncio
from datetime import datetime
from subprocess import Popen, PIPE
from concurrent.futures import ProcessPoolExecutor
from sen_click import product_page_start
from oper_env import win_platform, oper_environment, start_browser
from sen_log import ServiceLog

log_oper = ServiceLog(log_name='{}_{}_{}.log'.format(datetime.now().year, datetime.now().month,
                                                     datetime.now().day))
log_write = log_oper.logger_writer('{}'.format(datetime.now().day))


class cre_driver(object):
    def __init__(self):
        self.asy_loop = asyncio.get_event_loop()

    @staticmethod
    def renew_listen_port():
        """find a port to listen"""
        while True:
            rand_port = random.choice(range(1000, 10000))
            if win_platform():
                cmd_port = 'netstat -an | findstr {}'.format(rand_port)
            else:
                cmd_port = 'netstat -an | grep {}'.format(rand_port)
            pp = Popen(cmd_port, stdout=PIPE, stdin=PIPE, stderr=PIPE, shell=True)
            info, err = pp.communicate()
            if not info or info in ['', "b''", []]:
                pp.kill()
                return int(rand_port)
            else:
                pp.kill()
                continue

    @staticmethod
    def ret_pool_size():
        pool_size = multiprocessing.cpu_count() * 2
        return pool_size

    async def tasks(self, executor, op_port):
        tasks = [
            self.asy_loop.run_in_executor(executor, start_browser, op_port),
            self.asy_loop.run_in_executor(executor, product_page_start, op_port)
        ]
        await asyncio.gather(*tasks)

    def start_run(self, op_port):
        op_port = op_port

        executor = ProcessPoolExecutor(max_workers=2)
        self.asy_loop.run_until_complete(self.tasks(executor, op_port))

    @staticmethod
    def start_process():
        print('starting', multiprocessing.current_process().name)


def pool_start(start_run):
    """start eight browser"""
    port_list = []
    pool_size = cre_driver.ret_pool_size()
    for i in range(pool_size):
        listen_port = cre_driver.renew_listen_port()
        if listen_port:
            port_list.append(listen_port)
    print('port_list', port_list)
    proc_pool = multiprocessing.Pool(processes=pool_size, initializer=cre_driver.start_process, maxtasksperchild=2)
    proc_pool.map(start_run, port_list)
    proc_pool.close()
    proc_pool.join()


if __name__ == '__main__':
    pass
    eight_driver = cre_driver()
    pool_start(eight_driver.start_run)