# 异步的实现
import time
import asyncio


async def async_countdown(name, delay):
    # padding space for formatting
    indents = (ord(name) - ord('a')) * '\t'

    n = 3
    while n:
        await asyncio.sleep(delay)

        # elapsed time from the beginning
        duration = time.perf_counter() - start
        print('-' * 40)
        # message of the form: duration letter = countdown
        print(f'{duration:.4f} \t{indents}{name} = {n}')

        n -= 1


# 异步生成斐波那契函数
async def async_fib(n):
    print('start async_fib:', n)
    # if n = 0, say 0, if n = 1, say 1
    if n in [0, 1]:
        print(f'{n}: {n}')
        print(f'Took {time.perf_counter() - start:.2f} seconds.')

    # sequentially calculating fib(n)
    a, b = 1, 2
    i = 1
    while i < n:
        a, b = b, a + b

        if i % 50000 == 0:
            await asyncio.sleep(0) # switches task every 50,000 iterations

        i += 1

    # printing the last 20 digits if the result is too large
    print(f'{n}: {a % (10 ** 20)}')
    # printing the time elapsed from the beginning
    print(f'Took {time.perf_counter() - start:.2f} seconds.')

loop = asyncio.get_event_loop() # creating the event loop empty
# adding tasks to the task queue
tasks = [
    loop.create_task(async_countdown('a', 1)),
    loop.create_task(async_countdown('b', 0.8)),
    loop.create_task(async_countdown('c', 0.5))
]

start = time.perf_counter()
# run the event loop until all tasks are complete
loop.run_until_complete(asyncio.wait(tasks))     # 三个都需要等待，等待最短时间

print('-' * 40)
print('Done.')

# 利用多处理程序
from concurrent.futures import ProcessPoolExecutor
# 定义启动方式
def seq_fib(n):
    # if n = 0, say 0, if n = 1, say 1
    if n in [0, 1]:
        print(f'{n}: {n}')
        print(f'Took {time.perf_counter() - start:.2f} seconds.')

    # sequentially calculating fib(n)
    a, b = 1, 2
    i = 1
    while i < n:
        a, b = b, a + b
        i += 1

    # printing the last 20 digits if the result is too large
    print(f'{n}: {a % (10 ** 20)}')
    # print(str(n)[:20])
    # printing the time elapsed from the beginning
    print(f'Took {time.perf_counter() - start:.2f} seconds.')


async def main():
    tasks = [
        loop.run_in_executor(executor, seq_fib, 1000000),
        loop.run_in_executor(executor, seq_fib, 1000),
        loop.run_in_executor(executor, seq_fib, 20)
    ]

    await asyncio.gather(*tasks)

start2 = time.perf_counter()

executor = ProcessPoolExecutor(max_workers=3)     # 进程池来充分利用cpu多核能力
loop = asyncio.get_event_loop()
loop.run_until_complete(main())
loop = asyncio.get_event_loop() # creating the event loop
# adding tasks to the task queue
tasks = [
    loop.create_task(async_fib(1000000)),
    loop.create_task(async_fib(1000)),
    loop.create_task(async_fib(20))
]

# start = time.perf_counter()
print('start', start2)
# run the event loop until all tasks are complete
loop.run_until_complete(asyncio.wait(tasks))

print('Done.')