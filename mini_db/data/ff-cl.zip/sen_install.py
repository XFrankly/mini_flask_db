import os
import platform
from tkinter import messagebox
import tkinter
from subprocess import Popen, PIPE
from bin.oper_env import win_platform, def_chrome_path
from sen_log import ServiceLog
from datetime import datetime

log_oper = ServiceLog(log_name='{}_{}_{}.log'.format(datetime.now().year, datetime.now().month,
                                                     datetime.now().day))
log_write = log_oper.logger_writer('{}'.format(datetime.now().day))

the_palt = platform.platform()


# def win_platform():
#     if 'Window' in str(the_palt):
#         return True
#     else:
#         return False


def show_warning():
    if win_platform():
        pack_name = 'pack_install/windows/'
    else:
        pack_name = 'pack_install/mac/'
    log_info = '\n{}/{}'.format(
        os.path.dirname(os.path.realpath(__file__)), pack_name)
    print(log_info)
    log_write.info('{}'.format(log_info))
    err_title = u'浏览器未安装或版本错误'
    top = tkinter.Tk()
    if win_platform():
        top.tk.call('wm', 'iconphoto', top._w, tkinter.PhotoImage(file='favicon.ico'))
    top.overrideredirect(True)

    '''
    top.title(err_title)
    # top.place_slaves()
    # top.wm_grid()
    top.focus_displayof()
    top.geometry("1855x300")
    # root.overrideredirect(True)
    
    top.wm_attributes('-fullscreen', 'false')
    top.resizable(width='TRUE', height='FALSE')
    messg = u'需要更新浏览器版本到74.0.3\n 安装包在本机目录:{}'.format(log_info)

    top.wm_geometry("%dx%d%+d%+d" % (1855, 280, 0, 0))
    '''

    def hello_info():
        # tkinter.Tk().tk.call('wm', 'iconphoto', top._w, tkinter.PhotoImage(file='favicon.ico'))
        tkinter.messagebox.showwarning(title=err_title,
                                    message=u'需更新浏览器74.0.3\n 安装包本机路径，复制以下:{}'.format(log_info)
                                    )

    hello_info()
    # B1 = tkinter.Button(top, text=messg, command=hello_info)
    # B1.place(x=500, y=100)
    # top.mainloop()


chrome_path = ''
# if not win_platform():


def chrome_mac_version():
    """conform chrome version on mac"""
    path_cmd = """osascript -e 'POSIX path of (path to application "Chrome")'"""
    p_path = Popen(path_cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
    ret_p_path, err = p_path.communicate()
    log_write.debug('ret_p_path:{}, error:{}'.format(ret_p_path, err))

    if ret_p_path in ['', [], None, (), "b''"]:
        # FIXME
        log_write.debug('Please install chrome version 74.0.3')
        show_warning()
        raise AssertionError(u'请先按提示安装正确的浏览器版本。')
    else:
        ch_path = str(ret_p_path).replace('b', '')[1:-3]
        ch_path = ch_path.replace(' ', '\\ ')
        chrome_path = ch_path + 'Contents/MacOS/Google\ Chrome'
        chrom_ver_cmd = '{} --version'.format(chrome_path)
        log_write.info('info os chrom_ver_cmd: {}'.format(chrom_ver_cmd))

        p_version = Popen(chrom_ver_cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
        ver, verr = p_version.communicate()
        log_write.info('info now chrome version is:{}'.format(ver))
        if str(verr) not in ['', "b''"]:
            log_write.debug('Error Please install right version 74.0.3, search error:{}'.format(verr))
            show_warning()
            raise AssertionError(u'请先按提示安装正确的浏览器版本。')
        chrome_version = ver
        if '74.0.3' not in str(chrome_version):
            # FIXME
            log_write.debug('Error Please chrome version 74.0.3, now chrome version: {}'.format(chrome_version))
            show_warning()
            raise AssertionError(u'请先按提示安装正确的浏览器版本。')


def chrome_win_version():
    """conform chrome version on windows"""
    get_chrome_ver_cmd = """wmic datafile where name='path' get Version /value """
    w_version = Popen(get_chrome_ver_cmd, stderr=PIPE, stdin=PIPE, stdout=PIPE, shell=True)
