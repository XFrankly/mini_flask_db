import os
import tkinter
import random
import platform
from tkinter import messagebox
from datetime import datetime
from subprocess import Popen, PIPE
import threading
from get_env_info import ret_dict_obj, ck_env_leader
from sen_log import ServiceLog
from lib.selenium import webdriver

env_log_oper = ServiceLog(log_name='{}_{}_{}.log'.format('oper_environment', datetime.now().month,
                                                         datetime.now().day))
env_log_write = env_log_oper.logger_writer('{}'.format(datetime.now().day))
the_palt = platform.platform()
mac_def_chrome_path = "/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome "
ff_mac_install_path = "/Applications/Firefox.app/Contents/MacOS/firefox "


def win_platform():
    """check if pc or mac"""
    if 'Window' in str(the_palt):
        return True
    else:
        return False


def renew_listen_port():
    """find a port to listen"""
    while True:
        rand_port = random.choice(range(1000, 10000))
        if win_platform():
            cmd_port = 'netstat -an | findstr {}'.format(rand_port)
        else:
            cmd_port = 'netstat -an | grep {}'.format(rand_port)
        pp = Popen(cmd_port, stdout=PIPE, stdin=PIPE, stderr=PIPE, shell=True)
        info, err = pp.communicate()
        if not info or info in ['', "b''", []]:
            pp.kill()
            return int(rand_port)
        else:
            pp.kill()
            continue


class oper_environment(object):
    if ck_env_leader():
        _def_page = "https://www.learning.gov.cn/leader.php?event=1"
    else:
        _def_page = "https://pro.learning.gov.cn"
    _def_tech_page = "https://pro.learning.gov.cn"

    def __init__(self, port=None):
        if not port:
            self.listen_port = renew_listen_port()
        else:
            self.listen_port = port

    def ret_port(self):
        return self.listen_port

    @staticmethod
    def brow_driver_path():
        """only support windows and mac"""
        if 'Window' in str(platform.platform()):
            driver_path = './win_dri/chromedriver'
        else:
            driver_path = './mac_dri/chromedriver'
            # raise AssertionError('Error: platform not match:{}'.format(platform.platform()))
        env_log_write.info('Info the_palt:{} get driver_path:{}'.format(the_palt, driver_path))
        return driver_path

    @staticmethod
    def ff_driver_path():
        """only support windows and mac"""
        if 'Window' in str(platform.platform()):
            driver_path = './win_dri/geckodriver'
        else:
            driver_path = './mac_dri/geckodriver'
            # raise AssertionError('Error: platform not match:{}'.format(platform.platform()))
        env_log_write.info('Info the_palt:{} get driver_path:{}'.format(the_palt, driver_path))
        return driver_path

    @staticmethod
    def ret_win_user_name():
        """:return os current username"""
        if win_platform():
            user_current = "echo %username%"
            pw = Popen(user_current, stderr=PIPE, stdin=PIPE, stdout=PIPE, shell=True)

            user_curr, err = pw.communicate()
            if not user_curr:
                user_curr = 'hzhd'
            else:
                user_curr = str(user_curr)[2:-5]  # 获取当前用户名
        else:
            user_curr = None
        env_log_write.info('Info the_palt:{} get user_curr:{}'.format(the_palt, user_curr))
        return user_curr

    def ret_ff_cmd(self):
        if win_platform():
            def_exec_path = "dir"
        else:
            def_exec_path = """{} --start-debugger-server 6000 --private-window {} --wait-for-jsdebugger""".format(ff_mac_install_path, self._def_page)
        env_log_write.info('Info firefox the_palt, get def_exec_path:{}'.format(def_exec_path))
        return def_exec_path

    def ret_exec_cmd(self, url=None):
        """:return different executor command in diff platform"""
        if not url:
            url = self._def_page
        if win_platform():
            win_user = self.ret_win_user_name()
            # 禁用弹出拦截 --disable-popup-blocking  禁用gpu加速 --disable-gpu
            def_exec_path = "C:\\Users\\{}\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe " \
                            "{} --disable-popup-blocking [--headless] --disable-gpu --process-per-tab --remote-debugging-port={} ".format(
                win_user, url,
                self.listen_port)
        else:
            # check path and install version
            def_path = def_chrome_path()
            option = webdriver.ChromeOptions()
            option.add_argument('--disable-gpu')
            # chrome_mac_version(def_path)
            env_log_write.info('chrome path:{}'.format(def_path))
            def_exec_path = """{} {} [--headless] --disable-gpu  --disable-popup-blocking  --remote-debugging-port={} """.format(
                mac_def_chrome_path, url, self.listen_port)
        env_log_write.info('Info the_palt:{} get def_exec_path:{}'.format(the_palt, def_exec_path))
        return def_exec_path

    @staticmethod
    def forbid_path():
        """after install chrome browser by default path, forbid update"""
        if win_platform():
            pass
            user_current = "echo %username%"
            ban_path = "C:\\Users\\{}\\AppData\\Local\\Google\\Update"
        else:
            del_path = "/Library/Google/GoogleSoftwareUpdate/GoogleSoftwareUpdate.bundle"
            ban_path = "touch /Library/Google/GoogleSoftwareUpdate/GoogleSoftwareUpdate.bundle"
            mod_path = "chmod 111 /Library/Google/GoogleSoftwareUpdate/GoogleSoftwareUpdate.bundle"


def show_warning():
    """raise warning info"""
    if win_platform():
        pack_name = 'pack_install/windows/'
    else:
        pack_name = 'pack_install/mac/'
    log_info = '\n{}/{}'.format(
        os.path.dirname(os.path.realpath(__file__)), pack_name)
    print(log_info)
    env_log_write.info('{}'.format(log_info))
    err_title = u'浏览器未安装或版本错误'
    top = tkinter.Tk()
    if win_platform():
        top.tk.call('wm', 'iconphoto', top._w, tkinter.PhotoImage(file='favicon.ico'))
    top.overrideredirect(True)

    def hello_info():
        # tkinter.Tk().tk.call('wm', 'iconphoto', top._w, tkinter.PhotoImage(file='favicon.ico'))
        tkinter.messagebox.showwarning(title=err_title,
                                       message=u'需更新浏览器74.0.3\n 安装包本机路径，复制以下:{}'.format(log_info)
                                       )

    hello_info()


def chrome_mac_version(def_path):
    """conform chrome version on mac"""
    path_cmd = """osascript -e 'POSIX path of (path to application "Chrome")'"""
    p_path = Popen(path_cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
    ret_p_path, err = p_path.communicate()
    env_log_write.debug('ret_p_path:{}, error:{}'.format(ret_p_path, err))

    if ret_p_path in ['', [], None, (), "b''"]:
        # FIXME
        env_log_write.debug('Please install chrome version 74.0.3')
        show_warning()
        raise AssertionError(u'请先按提示安装正确的浏览器版本。')
    else:
        # ch_path = str(ret_p_path).replace('b', '')[1:-3]
        chrome_path = def_path
        chrom_ver_cmd = '{} --version'.format(chrome_path)
        env_log_write.info('info os chrom_ver_cmd: {}'.format(chrom_ver_cmd))

        p_version = Popen(chrom_ver_cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
        ver, verr = p_version.communicate()
        env_log_write.info('info now chrome version is:{}'.format(ver))
        if str(verr) not in ['', "b''"]:
            env_log_write.debug('Error Please install right version 74.0.3, search error:{}'.format(verr))
            show_warning()
            raise AssertionError(u'请先按提示安装正确的浏览器版本。')
        chrome_version = ver
        if '74.0.3' not in str(chrome_version):
            # FIXME
            env_log_write.debug('Error Please chrome version 74.0.3, now chrome version: {}'.format(chrome_version))
            show_warning()
            raise AssertionError(u'请先按提示安装正确的浏览器版本。')


def def_chrome_path():
    """if the chrome version is not match, raise warning info
    :return get default chrome path"""
    user_name = oper_environment.ret_win_user_name()
    if win_platform():
        # 禁用gpu加速，部分机器没有此功能
        # FIXME check version
        chrome_path = """C:\\Users\\{}\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe """.format(user_name)
        ban_cmd = "{} --disable-gpu"
    else:
        path_cmd = """osascript -e 'POSIX path of (path to application "Chrome")'"""
        p_path = Popen(path_cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
        ret_p_path, err = p_path.communicate()
        env_log_write.debug('ret_p_path:{}, error:{}'.format(ret_p_path, err))
        if ret_p_path in ['', [], None, (), "b''"]:

            env_log_write.debug('Please install chrome version 74.0.3')
            show_warning()
            raise AssertionError(u'请先按提示安装正确的浏览器版本。')
        else:
            ch_path = str(ret_p_path).replace("b", '')[1:-3]
            ch_path = ch_path.replace(' ', '\\ ')
            chrome_path = ch_path + 'Contents/MacOS/Google\ Chrome'
        # chrome_path = """"""
    env_log_write.info('Info the_palt:{} get default chrome_path:{}'.format(the_palt, chrome_path))
    return chrome_path


def start_ff_brow(port=None):
    ins_oper = oper_environment(port)
    ff_start = ins_oper.ret_ff_cmd()
    pf = Popen(ff_start, stdin=PIPE, stderr=PIPE, stdout=PIPE, shell=True)
    pf.communicate()
    pf.wait()


def start_browser(port=None, url=None):
    if not win_platform():
        chrome_mac_version(mac_def_chrome_path)
    ins_oper = oper_environment(port)
    exec_start = ins_oper.ret_exec_cmd(url=url)

    pe = Popen(exec_start, stdin=PIPE, stderr=PIPE, stdout=PIPE, shell=True)
    pe.communicate()
    pe.wait()


if __name__ == '__main__':
    pass
    """
    pidthreads =[]
    rstdic = {}
    t0 = threading.Thread(target=note_port, args=(9901,))
    print('threading obj', t0.name)
    t0.daemon = True

    ts = t0.start()
    print('ts', ts)
    t0.join()
    print(t0.isAlive())
    obj = threading.current_thread()
    pidthreads.append(obj)
    rstdic[t0.name] = (t0.isAlive())
    disRst(t0.isAlive(), t0.isDaemon())
    print(rstdic, pidthreads)
    """
    # start_browser()
    start_ff_brow()

    # exec_start = oper_environment().ret_exec_cmd()
    # pe = Popen(exec_start, stdin=PIPE, stderr=PIPE, stdout=PIPE, shell=True)
    # info, err=pe.communicate()
    # print('info,error', info, str(err))
    # pe.wait()
    # print(pe.returncode)
