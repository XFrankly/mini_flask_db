import pyautogui
import datetime
import time
import random
import platform
from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver

position = (58, 73)
in_times = 0


t1 = datetime.datetime.now()


print('start time:', t1)


def renew_wait_min(in_times):
    wait_min = 1
    while in_times < 3:
        in_times += 1
        try:
            wait_min = input("activate wait minutes:")
            wait_min = int(wait_min)
            assert type(wait_min) == int
            break
        except TypeError as e:
            print('type error {}, please retry, like 3, means 3 minutes'.format(e))
    return wait_min


def start_move(wait_min):
    time1 = time.time()
    while True:
        time.sleep(3)
        t2 = datetime.datetime.now()
        time2 = time.time()
        rand_int = random.randint(-10, 10)
        print(t2)
        print(datetime.datetime.strptime(str(t2), '%Y-%m-%d %H:%M:%S.%f') - datetime.datetime.strptime(str(t1),
                                                                                                       '%Y-%m-%d %H:%M:%S.%f'))
        if time2 - time1 >= wait_min * 60:
            print("its time to click", t2)
            print(pyautogui.position())
            # pyautogui.click(x=position[0] + rand_int, y=position[1] + rand_int, button='left')
            pyautogui.move(xOffset=position[0] + rand_int, yOffset=position[1] + rand_int)
            print("Done click.")
            print("Now i am at", pyautogui.position())
            print('t1.minute', t1.minute)
            print('t1', t1)
            time1 = time1 + (wait_min * 60)

            # break
        else:
            print("wait for activate")
            continue

'''
# import win32gui
import re


class WindowMgr:
    """Encapsulates some calls to the winapi for window management"""

    def __init__ (self):
        """Constructor"""
        self._handle = None

    def find_window(self, class_name, window_name=None):
        """find a window by its class_name"""
        # self._handle = win32gui.FindWindow(class_name, window_name)
        self._handle = pyautogui.FindWindow(class_name, window_name)

    def _window_enum_callback(self, hwnd, wildcard):
        """Pass to win32gui.EnumWindows() to check all the opened windows"""
        if re.match(wildcard, str(win32gui.GetWindowText(hwnd))) is not None:
            self._handle = hwnd

    def find_window_wildcard(self, wildcard):
        """find a window whose title matches the wildcard regex"""
        self._handle = None
        win32gui.EnumWindows(self._window_enum_callback, wildcard)

    def set_foreground(self):
        """put the window in the foreground"""
        win32gui.SetForegroundWindow(self._handle)
'''


if __name__ == '__main__':
    print(platform.platform())

    start_move(renew_wait_min(in_times))
    driver = webdriver.Chrome()
    above = driver.find_element_by_xpath('xxx')
    actions = ActionChains(driver)

    actions.move_to_element(above)
    actions.click()
    actions.perform()

    # actions = ActionChains(driver)
    # actions.move_to_element(menu)
    # actions.click(hidden_submenu)
    # actions.perform()

