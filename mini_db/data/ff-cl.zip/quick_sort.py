
def QuickSort(ls):
    def partition(lis, left, right):
        key = left
        while left < right:
            while left < right and lis[right] >= lis[key]:
                right -= 1
            while left < right and lis[left] <= lis[key]:
                left += 1
            (lis[left], lis[right]) = (lis[right], lis[left])
        (lis[left], lis[key]) = (lis[key], lis[left])
        return left

    def quicksort(lis, left, right):  # 递归调用
        if left >= right:
            return
        mid = partition(lis, left, right)
        quicksort(lis, left, mid - 1)
        quicksort(lis, mid + 1, right)

    # 主函数
    n = len(ls)
    if n <= 1:
        return ls
    quicksort(ls, 0, n - 1)
    return ls


class SMTPConnection():
    def __init__(self, url, port, username, password):
        self.client   = SMTPAsync()
        self.url      = url
        self.port     = port
        self.username = username
        self.password = password

    async def __aenter__(self):
        await self.client.connect(self.url, self.port)
        await self.client.starttls()
        await self.client.login(self.username, self.password)

        return self.client

    async def __aexit__(self, exc_type, exc, tb):
        await self.client.quit()


if __name__ == '__main__':
    print(QuickSort(list('121212223464574')))