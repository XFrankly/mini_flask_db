import urllib
import requests

class req(object):
    def __init__(self):
        self.session = requests.session()

    def get(self, url, headers=None):
        if headers is None:
            headers = {}

        response = self.session.get(url)
        return response


class Context(object):
    def __init__(self, flag):
        self.flag = flag
        print('int __init__')


    def __enter__(self):
        print('in __enter__')
        # return req()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        print('in __exit__')
        print(f'exc_type = {exc_type }')
        print(f'exc_val = {exc_val}')
        print(f'exc_tb = l{exc_tb}')
        return self.flag     # 返回为True，打印异常， 返回False，抛出异常


import contextlib

class Context_two(contextlib.ContextDecorator):
    def __init__(self, how_used):
        self.how_used = how_used
        print(f'__init__{how_used}')
    def __enter__(self):
        print(f'__enter__({self.how_used})')
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        print(f'__exit__({self.how_used})')


@Context_two('as a decorator')
def func1(message):
    print(f'{message}')


@contextlib.contextmanager
def make_context_3():
    print('enter make_context')
    try:
        yield {}    # 生成器函数转化为装饰器
    except RuntimeError as ert:
        print(f'ert= {ert}')

print('Normal')

with make_context_3() as value1:
    print('in with')

print('runtime error')

with make_context_3() as value1:
    raise RuntimeError("runtimeerror")

# print('Else Error')
# with make_context_3() as value3:
#     raise ZeroDivisionError('除0错误')

if __name__ == '__main__':
    with Context(True) as ct:
        # reqs = ct.get('https://www.baidu.com')
        # print(reqs.text)
        raise RuntimeError()


    with Context(True) as ct2:
        raise RuntimeError()

    print('==' * 20)
    func1('作为装饰器')


    with Context_two('上下文管理器') as  ct3:
        print('en212@')

