
from concurrent.futures import ProcessPoolExecutor
import asyncio

from subprocess import Popen, PIPE
from datetime import datetime
import random
from sen_click import product_page_start
from oper_env import win_platform, oper_environment, start_browser
from sen_log import ServiceLog

log_oper = ServiceLog(log_name='{}_{}_{}.log'.format(datetime.now().year, datetime.now().month,
                                                     datetime.now().day))
log_write = log_oper.logger_writer('{}'.format(datetime.now().day))


def renew_listen_port():
    """find a port to listen"""
    while True:
        rand_port = random.choice(range(1000, 10000))
        if win_platform():
            cmd_port = 'netstat -an | findstr {}'.format(rand_port)
        else:
            cmd_port = 'netstat -an | grep {}'.format(rand_port)
        pp = Popen(cmd_port, stdout=PIPE, stdin=PIPE, stderr=PIPE, shell=True)
        info, err = pp.communicate()
        if not info or info in ['', "b''", []]:
            pp.kill()
            return int(rand_port)
        else:
            pp.kill()
            continue

executor = ProcessPoolExecutor(max_workers=2)
loop = asyncio.get_event_loop()
async def tasks(op_port):
    tasks = [
             loop.run_in_executor(executor, start_browser, op_port),
             loop.run_in_executor(executor, product_page_start, op_port)
             ]
    await asyncio.gather(*tasks)


def start_process():
    print('starting', multiprocessing.current_process().name)


def start_one_driver(port):
    loop.run_until_complete(tasks(port))

if __name__ == '__main__':
    #op_port = renew_listen_port()
    """DEMO"""
    port_list = [1314, 8990, 1902, 2241, 2270, 7464, 9361, 2281]


    import multiprocessing
    proc_pool = multiprocessing.Pool(processes=8, initializer=start_process, maxtasksperchild=2)
    # proc_pool.map(start_one_driver, port_list)
    proc_pool.apply(start_one_driver, port_list)
    proc_pool.close()
    proc_pool.join()