# -*- coding: utf-8 -*-
import os

curr_dir = os.path.dirname(os.path.realpath(__file__))
print(curr_dir)

conf_path = curr_dir + os.sep + './conf/'
print(conf_path)
global_conf_path = conf_path + 'configure.conf'


class DictObj(object):
    def __init__(self, dicts):
        for key, value in dicts.items():
            if isinstance(value, (list, tuple)):
                setattr(self, key, [DictObj(x) if isinstance(x, dict) else x for x in value])
            else:
                setattr(self, key, DictObj(value) if isinstance(value, dict) else value)

    def __repr__(self):
        return str(self.__dict__)

    def __getitem__(self, key):
        assert hasattr(self, key)
        return getattr(self, key)

    def put(self, key, value):
        if isinstance(value, (list, tuple)):
            setattr(self, key, [DictObj(x) if isinstance(x, dict) else x for x in value])
        else:
            setattr(self, key, DictObj(value) if isinstance(value, dict) else value)


def ret_dict_obj():
    with open(global_conf_path, 'r') as f:
        print("get config from {}".format(global_conf_path))
        gl_config = f.read()
        configure_conf = eval(gl_config)
        configure_obj = DictObj(configure_conf)
        f.close()
    return configure_obj


def ck_env_leader():
    environment = ret_dict_obj().env
    return environment == 'leader'


def ck_env_technique():
    env_tech = ret_dict_obj().technique
    return int(env_tech) == 1


if __name__ == '__main__':
    configure_obj = ret_dict_obj()
    print(configure_obj.env)
    print(ck_env_leader())