

import time
import webbrowser
import os
import time
import platform
from _datetime import datetime
from get_env_info import ret_dict_obj, ck_env_technique, ck_env_leader
from lib.selenium import webdriver
from lib.selenium.webdriver import ChromeOptions
from lib.selenium.webdriver.common.action_chains import ActionChains
from lib.selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from subprocess import Popen, PIPE
from oper_env import win_platform, oper_environment, start_browser
from sen_log import ServiceLog
from urllib import request as urlrequest
import  socket, sys
from _thread import *

log_oper = ServiceLog(log_name='ff_{}_{}_{}.log'.format(datetime.now().year, datetime.now().month,
                                                            datetime.now().day))
log_write = log_oper.logger_writer('{}'.format(datetime.now().day))

try:
    listening_port = int(input("[*] Enter Listening Port: "))
except KeyboardInterrupt:   # ctrl + c 关闭页面
    log_write.info("\n [*] User Requested An Interrupt")
    log_write.info("[*] Application Exiting ...")
    sys.exit()

max_conn = 5    # 代理服务器的最大链接数
buffer_size = 81920

""" 我们将创建3个函数
Function 1: start() - Main Program
Function 2: conn_string() - Retrieve Connection Details 取回连接详细信息
Function 3: proxy_server() - Make connection to end server 连接到终端服务器

"""
def start():
    """1,设置socket
    2，绑定监听端口到socket
    3，开始监听以备到来到连接"""
    # start 这样做是为了启动主程序....我们现在有一个工作的python脚本.....
    #
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # 初始化socket
        log_write.info("[*] Initializing Sockets ... Done ...")
        s.bind(('', listening_port))  # 绑定 监听端口到 Socket
        log_write.info("[*] Sockets Binded Successfully ... Done")
        s.listen(max_conn)
        log_write.info("[*] Server Started Successfully ... [ {} ]".format(listening_port))
    except Exception as  e:
        log_write.info("[*] Unable To Initialize Socket error: {}".format(e))
        sys.exit(2)

    while True:
        try:
            conn, addr = s.accept()  # 从浏览器 接受连接请求 conn 连接 stream，addr 发起连接的地址
            log_write.info("[*] conn:{}, addr:{}".format(conn, addr))
            # log_write.info("[*] conn:{}, dir:{}".format(type(conn), dir(conn)))
            data = conn.recv(buffer_size)  # 接受客户端数据
            start_new_thread(conn_string, (conn, data, addr)) # 开启一个线程
        except KeyboardInterrupt:
            # 用户按键退出 ctrl + c
            s.close()
            log_write.info("[*] Proxy Server Shutting Down ...")
            log_write.info("[*] Bye ...")
            sys.exit(1)
    s.close()

def conn_string(conn, data, addr):
    # 客户端请求 信息 在这里处理,
    # 这个函数conn_string基本上做的是在接收到的客户端数据中检索主机地址，端口（如果由客户端指定），调用另一个函数proxy_server并向其传递五个参数。
    """webserver - host address
    port - webserver port
    conn - connection stream
    addr - address from connection stream.
    data - client browser data"""
    log_write.info('conn msg:{}, data:{}, addr:{}'.format(conn, data, addr))
    data = str(data)
    try:
        first_line = data.split('\n')[0]
        log_write.info('first_line msg:{}'.format(first_line))
        url = first_line.split(' ')[1]
        http_pos = url.find("://")   # Find the Position of ://
        log_write.info('url msg:{} http_pos:{}'.format(url, http_pos))
        if (http_pos == -1):
            temp = url
        else:
            temp = url[(http_pos + 3):] # Get the rest of the url

        port_pos = temp.find(":")  # 获取Pos 的请求端口
        log_write.info('port_pos temp:{} webserver_pos:{}'.format(temp, port_pos))
        webserver_pos = temp.find("/") # 找到web server 终点，end point(f any)
        log_write.info('port_pos msg:{} webserver_pos:{}'.format(port_pos, webserver_pos))
        if webserver_pos == -1:
            webserver_pos = len(temp)
        webserver = ""
        port = -1
        if (port_pos == -1 or webserver_pos < port_pos):
            port = 80
            webserver = temp[:webserver_pos]
        else:
            # specific port
            port = int((temp[(port_pos+1):])[:webserver_pos - port_pos - 1])
            webserver = temp[:port_pos]
        proxy_server(webserver, port ,conn, addr, data)
        log_write.info('webserver:{}, port:{} ,conn:{}, addr:{}, data:{}'.format(webserver, port, conn, addr, data))
        log_write.info('proxy_server msg:{}'.format(proxy_server))
    except Exception as e1:
        log_write.info('conn error msg:{}'.format(e1))
        pass


def proxy_server(webserver, port , conn, addr, data):
    import urllib
    """此函数创建一个新套接字，连接到Web服务器并发送客户端请求，接收回复，将其转发回客户端而不修改它，打印自定义成功消息并关闭流"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        conn_msg = s.connect((webserver, port))
        log_write.info('conn  msg:{}, conn_msg:{}'.format(s, conn_msg))
        s_msg = s.send(data)
        log_write.info('send msg:{}, s_msg:{}'.format(s, s_msg))
        while True:
            # Read reply or data to from end web server
            # reply = s.recv(buffer_size)
            reply = s.recv(4096)
            log_write.info('socket:{}, reply:{}'.format(s, reply))
            if len(reply) > 0:
                conn.send(reply)  # 发reply 回客户端
                # 发送警告到代理服务器
                dar = float(len(reply))
                dar = float(dar / 1024)
                dar = "{:.3s}".format(str(dar))
                dar = "{} KB".format(dar)
                # print A custom message for request complete
                log_write.info("[*] Request Done {} ==> {}...".format(str(addr[0]), str(dar)))
            else:
                # if receiving data fail, break
                break
        s.close()  # Feel Free To Close Our Server Sockets
        conn.close()  # Now that everthing is sent, We may now close our client sock
    except socket.error as se:
        s.close()
        conn.close()
        sys.exit(1)

#
# proxy_host = 'https://195.154.231.43:3128'    # host and port of your proxy
# url1 = 'https://www.learning.gov.cn/leader.php'
# req = urlrequest.Request(url1)
# req.set_proxy(proxy_host, 'http')
#
# response = urlrequest.urlopen(req)
# print(response.read().decode('utf8'))
#
#
# ip = '192.168.31.1:80'
# chome_options = webdriver.ChromeOptions()
# chome_options.add_argument(('--proxy-server=http://' + ip))
#
# url = 'https://www.learning.gov.cn/leader.php?event=1'
# driver = webdriver.Chrome(executable_path=oper_environment.brow_driver_path(), chrome_options=chome_options)
# # chrom_option.debugger_address = '127.0.0.1:{}'.format(self.port)
# driver.get(url)
# time.sleep(12)
# print(driver.page_source)
# driver.close()
if __name__ == '__main__':
    start()